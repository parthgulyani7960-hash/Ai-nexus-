import { auth } from '../src/firebase.js';
const email=process.argv[2];if(!email){console.error('Usage: npm run create-admin -- user@example.com');process.exit(1)}
const user=await auth.getUserByEmail(email);await auth.setCustomUserClaims(user.uid,{...(user.customClaims||{}),nexusAdmin:true});console.log(`Granted nexusAdmin claim to ${email}.`);
