import { env } from './config.js';
import type { Provider } from './types.js';

export interface ModelRequest { provider:Provider; model:string; system:string; prompt:string; }
export async function generate(req:ModelRequest):Promise<string>{
  const timeoutMs=90000;
  if(req.provider==='gemini'){
    if(!env.GEMINI_API_KEY) throw new Error('Gemini API key is not configured.');
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeoutMs);
    try{
      const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(req.model)}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':env.GEMINI_API_KEY},signal:controller.signal,body:JSON.stringify({systemInstruction:{parts:[{text:req.system}]},contents:[{role:'user',parts:[{text:req.prompt}]}],generationConfig:{maxOutputTokens:env.MAX_OUTPUT_TOKENS,temperature:0.35}})});
      const data:any=await response.json();
      if(!response.ok)throw new Error(data?.error?.message||`Gemini returned HTTP ${response.status}`);
      const text=data?.candidates?.[0]?.content?.parts?.map((p:any)=>p.text||'').join('');
      if(typeof text!=='string'||!text.trim())throw new Error('Gemini returned an empty response.');
      return text;
    }finally{clearTimeout(timer);}
  }
  const key=req.provider==='groq'?env.GROQ_API_KEY:env.OPENROUTER_API_KEY;
  if(!key) throw new Error(`${req.provider} API key is not configured.`);
  const url=req.provider==='groq'?'https://api.groq.com/openai/v1/chat/completions':'https://openrouter.ai/api/v1/chat/completions';
  const headers:Record<string,string>={'Authorization':`Bearer ${key}`,'Content-Type':'application/json'};
  if(req.provider==='openrouter'){if(env.OPENROUTER_SITE_URL)headers['HTTP-Referer']=env.OPENROUTER_SITE_URL;headers['X-Title']=env.OPENROUTER_APP_NAME;}
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeoutMs);
  try{
    const response=await fetch(url,{method:'POST',headers,signal:controller.signal,body:JSON.stringify({model:req.model,messages:[{role:'system',content:req.system},{role:'user',content:req.prompt}],temperature:0.35,max_tokens:env.MAX_OUTPUT_TOKENS})});
    const data:any=await response.json();
    if(!response.ok)throw new Error(data?.error?.message||`${req.provider} returned HTTP ${response.status}`);
    const content=data?.choices?.[0]?.message?.content;
    if(typeof content!=='string'||!content.trim())throw new Error(`${req.provider} returned an empty response.`);
    return content;
  }finally{clearTimeout(timer);}
}
