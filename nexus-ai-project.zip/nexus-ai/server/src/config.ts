import 'dotenv/config';
import { z } from 'zod';
const schema = z.object({
  PORT: z.coerce.number().default(10000),
  NODE_ENV: z.string().default('development'),
  CLIENT_ORIGIN: z.string().default('http://localhost:5173'),
  FIREBASE_PROJECT_ID: z.string().min(1),
  FIREBASE_CLIENT_EMAIL: z.string().email(),
  FIREBASE_PRIVATE_KEY: z.string().min(1),
  GEMINI_API_KEY: z.string().optional(),
  GROQ_API_KEY: z.string().optional(),
  OPENROUTER_API_KEY: z.string().optional(),
  OPENROUTER_SITE_URL: z.string().optional(),
  OPENROUTER_APP_NAME: z.string().default('NEXUS AI'),
  GEMINI_MODEL: z.string().default('gemini-3.8-flash'),
  GROQ_MODEL: z.string().default('openai/gpt-oss-120b'),
  OPENROUTER_MODEL: z.string().default('openrouter/free'),
  MAX_TASK_CHARS: z.coerce.number().default(12000),
  MAX_OUTPUT_TOKENS: z.coerce.number().default(4096),
  WORKER_POLL_MS: z.coerce.number().default(2500),
  JOB_LEASE_MS: z.coerce.number().default(120000),
  MAX_CONCURRENT_TASKS: z.coerce.number().default(2),
  RATE_LIMIT_WINDOW_MS: z.coerce.number().default(60000),
  RATE_LIMIT_MAX: z.coerce.number().default(20)
});
export const env = schema.parse(process.env);
export const providerAvailability = () => ({gemini:!!env.GEMINI_API_KEY,groq:!!env.GROQ_API_KEY,openrouter:!!env.OPENROUTER_API_KEY});
