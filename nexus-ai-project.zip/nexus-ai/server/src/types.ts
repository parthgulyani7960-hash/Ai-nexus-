export type Provider = 'gemini'|'groq'|'openrouter';
export type AgentName = 'Research AI'|'Logic AI'|'Coding AI'|'Critic AI'|'Security AI'|'Master AI';
export type AgentStatus = 'queued'|'running'|'completed'|'failed'|'skipped';
export interface AgentRecord { name:AgentName; provider:Provider; model:string; status:AgentStatus; prompt?:string; output?:string; error?:string; startedAt?:number; completedAt?:number; durationMs?:number; }
export interface TaskRecord { id:string; uid:string; title:string; prompt:string; status:'queued'|'running'|'completed'|'failed'; phase:string; progress:number; agents:Record<string,AgentRecord>; reviews:Array<{reviewer:string;target:string;findings:string;revisionRequested:boolean}>; finalResult?:string; error?:string; createdAt:number; updatedAt:number; leaseUntil?:number; workerId?:string; }
