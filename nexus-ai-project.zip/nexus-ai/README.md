# NEXUS AI — Multi-Agent Collaboration Platform

A React + Node.js + Firebase starter that dispatches one task to Gemini, Groq and OpenRouter, persists agent outputs in Firestore, performs peer review, optionally revises reports, and asks Gemini to synthesize a final deliverable.

## Important status and limits

This is a deployable starter implementation, not a certified production system. You must configure Firebase, provider credentials, model IDs and billing/rate limits, test the deployed system, and review security before real users or sensitive workloads. Provider free tiers change and are not guaranteed. The configured model IDs are defaults based on provider catalogs checked in November 2026; model access, free-tier eligibility and pricing vary by account. Gemini defaults to `gemini-3.8-flash`, Groq to `openai/gpt-oss-120b`, and OpenRouter to `openrouter/free`. These models currently have free access paths, but only within provider-specific quotas and account eligibility; check each console before use. Groq's published free-plan limits for GPT-OSS 120B include 30 requests/minute, 1,000/day and 8,000 tokens/minute; OpenRouter free models are limited to 50 requests/day and 20/minute on a free account. Gemini free-tier availability is model-specific and Google says unpaid-tier content may be used to improve its products. OpenRouter's free route is rate-limited and availability is not guaranteed.

The worker uses Firestore transactional leases and lease heartbeats so queued work is persisted and can be reclaimed after a process interruption. This is a lightweight queue, not a full distributed queue: for higher throughput use Cloud Tasks, Pub/Sub, or a dedicated queue service. Test lease behavior under Render restarts and concurrent instances before scaling.

## Architecture

- `client/`: React + TypeScript Vite dashboard; Firebase email/password authentication; task history, agent status, report tabs, cross-review and final result.
- `server/`: Express API, Firebase Admin authentication, Firestore task persistence, model adapters, queue poller and orchestration.
- Initial specialist agents run concurrently: Research (Gemini), Logic (Groq), Coding (OpenRouter), Critic (Groq), Security (OpenRouter).
- Six peer-review jobs run across those providers. Reports flagged for revision receive one bounded revision pass. Gemini Master receives original task, reports and review findings.
- The browser polls the authenticated task endpoint for updates. This avoids EventSource's inability to set a bearer Authorization header. An authenticated SSE endpoint is also included for a future fetch-stream client.

## 1. Firebase setup

1. Create a Firebase project at https://console.firebase.google.com/.
2. Add a Web App and copy its `apiKey`, `authDomain`, `projectId`, and `appId` into `client/.env.local`.
3. Enable Authentication → Sign-in method → Email/Password.
4. Create a Firestore database.
5. Create a service account in Google Cloud / Firebase project settings. Keep the JSON private. Put its `project_id`, `client_email`, and `private_key` into the server environment as `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, and `FIREBASE_PRIVATE_KEY`. In Render, paste the private key with newline characters preserved or as `\\n`; the server normalizes escaped newlines.
6. Deploy `firestore.rules` (or equivalent) so browser clients cannot read/write `nexusTasks`; the server uses Admin SDK.
7. Add the Render backend domain to Firebase Authentication → Settings → Authorized domains.

## 2. Provider keys

Create keys in the providers' official consoles. Never commit keys or put them in Vite variables:
- Gemini: https://aistudio.google.com/apikey
- Groq: https://console.groq.com/keys
- OpenRouter: https://openrouter.ai/keys

Set `GEMINI_API_KEY`, `GROQ_API_KEY`, and `OPENROUTER_API_KEY` only in the server environment. You can override model IDs with `GEMINI_MODEL`, `GROQ_MODEL`, and `OPENROUTER_MODEL`. Do not paste secrets into source code, issues, screenshots or chat. Configure provider spend limits where available. Free tiers have changing quotas, model eligibility, data-use terms and rate limits; check each provider's current terms before use. One full NEXUS run can make roughly 12–17 model requests because of parallel reports, peer reviews, possible revisions and final synthesis, so provider free quotas can be consumed quickly.

## 3. Local development

Requirements: Node.js 20+ and npm.

```bash
npm install
cp .env.example server/.env
cp client/.env.example client/.env.local
```

Edit `server/.env` and `client/.env.local` with your own configuration. Then:

```bash
npm run dev
```

Frontend: http://localhost:5173  
Backend: http://localhost:10000/health

For local Firebase Admin credentials, use the three server variables documented above. Do not use a service-account JSON file in the repository.

## 4. Deploy to Render

1. Push this project to a private GitHub repository.
2. In Render, create a Web Service from that repository.
3. Build command: `npm install && npm run build`
4. Start command: `npm start`
5. Set all server environment variables from `.env.example` in Render. Set `CLIENT_ORIGIN` to the exact deployed frontend origin(s), comma-separated if needed.
6. For simplest deployment, serve the Vite client separately (e.g. Render Static Site) using root directory `client`, build command `npm install && npm run build`, publish directory `dist`. Add the `VITE_API_URL` and Firebase web config variables at build time. The included Render backend blueprint uses the Free plan; free web services may spin down after inactivity, so queued work will pause while the service sleeps and resume only after it wakes. For reliable always-on background processing, use an always-on service or a separate managed worker.
7. If using a separate static site, set backend `CLIENT_ORIGIN` to its exact HTTPS origin. Add the backend domain to Firebase Auth authorized domains.
8. Check `https://YOUR-BACKEND/health` and sign in through the frontend.

You can also deploy the backend as a Render Web Service and frontend as a separate Render Static Site. This is recommended for independent scaling. The included `render.yaml` describes the backend service only.

## 5. API endpoints

All `/api/*` endpoints require `Authorization: Bearer <Firebase ID token>` except `/health`.

- `GET /health`
- `GET /api/providers` — configured-provider presence (never returns keys)
- `POST /api/tasks` — `{ "prompt": "..." }`
- `GET /api/tasks` — latest 40 tasks for current user
- `GET /api/tasks/:id` — task state and outputs, owner-checked
- `GET /api/tasks/:id/events` — authenticated SSE endpoint (bearer token in header; browser EventSource cannot set headers; use fetch streaming or the frontend's authenticated polling)

## 6. Production hardening checklist

Before public launch:
- Replace the starter model IDs with currently available models and test each provider's request/response format.
- Add per-user quotas, provider-specific concurrency limits, cost ceilings, and daily budget alarms.
- Add Firestore indexes if prompted by query errors; the task list query uses `uid` + `createdAt`.
- Add task cancellation, idempotency keys, retention/deletion controls, and request audit logs.
- Add worker lease heartbeats and transactional compare-and-set updates before multiple worker replicas.
- Add provider retry with exponential backoff and respect `Retry-After`; avoid blindly retrying quota/billing errors.
- Validate outputs and treat model-generated text as untrusted. Never execute generated code or tools automatically.
- Configure a restrictive Content Security Policy appropriate to your frontend hosting and avoid wildcard CORS.
- Review provider data retention/training terms; don't send payment credentials, bank data, secrets, or sensitive personal information to free-tier endpoints.
- Add automated tests, dependency scanning, backups, alerting and an incident response process.

## Current implementation notes

The API stores prompts, provider/model metadata, agent outputs, review results and final synthesis in Firestore. The UI renders full reports and task progress. Agent execution is genuinely performed through configured provider APIs; if a provider is missing or a model is unavailable, that agent is marked failed and the other agents continue. The final synthesis proceeds when at least one specialist report succeeds; failed agents are disclosed in the task record. This behavior should be tightened to your preferred completion policy before launch.
